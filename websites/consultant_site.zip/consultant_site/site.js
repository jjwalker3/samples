$(window).load(function () {
    $("#logo-large").fadeIn(1000);
    $("h1").delay(500).fadeIn(1000);
});


$(document).ready(function () {
    $(".pic").shuffle();

    $('#banner').cycle({
        fx: 'fade',
        speed: 1000,
        timeout: 10000, // choose your transition type, ex: fade, scrollUp, shuffle, etc...
    });

});



$("#landing").click(function () {

    $("#landing").fadeOut(500);

    $("#logo-small").delay(500).fadeIn(500);

    $("#banner").delay(1000).fadeIn(500);

    $("#navigation").children().removeClass("active-nav");

    $("#values").addClass("active-nav");

    $("#navigation").delay(1500).fadeIn(750);

    $("#values-content").delay(2250).fadeIn(750);


});

$("#logo-small").click(function () {

    $("#logo-small").fadeOut(500);

    $("#banner").fadeOut(500);

    $("#navigation").fadeOut(500);

    $("#content").children().fadeOut(500);

    $("#landing").delay(1000).fadeIn(500);

});


$("#values").click(function () {

    $(".content-area").fadeOut(500);

    $("#navigation").children().removeClass("active-nav");

    $(this).addClass("active-nav");

    $("#values-content").delay(500).fadeIn(500);

});


$("#services").click(function () {

    $(".content-area").fadeOut(500);

    $("#navigation").children().removeClass("active-nav");

    $(this).addClass("active-nav");

    $("#services-content").delay(500).fadeIn(500);

});


$("#clients").click(function () {

    $(".content-area").fadeOut(500);

    $("#navigation").children().removeClass("active-nav");

    $(this).addClass("active-nav");

    $("#clients-content").delay(500).fadeIn(500);

});


$("#contact").click(function () {

    $(".content-area").fadeOut(500);

    $("#navigation").children().removeClass("active-nav");

    $(this).addClass("active-nav");

    $("#contact-content").delay(500).fadeIn(500);

});