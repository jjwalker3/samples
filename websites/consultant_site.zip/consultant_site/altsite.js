$(window).load(function () {
    $("#container").fadeIn(500);
});


$(document).ready(function () {
    $(".pic").shuffle();

    $('#banner').cycle({
        fx: 'fade',
        speed: 1000,
        timeout: 10000, // choose your transition type, ex: fade, scrollUp, shuffle, etc...
    });

});

$("#logo-small").click(function () {
    $("#container").fadeOut(500);



    setTimeout(function () {
        window.location.href = 'http://www.wikipedia.org';
    }, 500);


});