<?php


//session_start();


if($_SERVER["REQUEST_METHOD"] == "POST")
{
$recaptcha=$_POST['g-recaptcha-response'];
if(!empty($recaptcha))
{

$google_url="https://www.google.com/recaptcha/api/siteverify";
$secret='6LdAOvoSAAAAAMQLkGubNOrkri_zaKD8dhpzKiIS';
$ip=$_SERVER['REMOTE_ADDR'];
$url=$google_url."?secret=".$secret."&response=".$recaptcha."&remoteip=".$ip;

    
function getCurlData($url)
{
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_TIMEOUT, 10);
curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16");
$curlData = curl_exec($curl);
curl_close($curl);
return $curlData;
}    
    
    
$res=getCurlData($url);
$res= json_decode($res, true);
//reCaptcha success check 
if($res['success'])
{
//put happy code here!!!!!!!!!
                                header("Location: https://en.wikipedia.org/wiki/Special:Random");

                                if(isset($_POST['email'])) {



                                // EDIT THE 2 LINES BELOW AS REQUIRED

                                $email_to = "jeremy.walker.library@gmail.com";

                                $email_subject = "WEBSITE - CONTACT SUBMISSION";


                                $name = $_POST['name']; // required

                                $email_from = $_POST['email']; // required

                                $telephone = $_POST['telephone']; // not required

                                $message = $_POST['message']; // required
                                
                                
                                function clean_string($string) {

                                  $bad = array("content-type","bcc:","to:","cc:","href");

                                  return str_replace($bad,"",$string);

                                }



                                $email_message .= "Name: ".clean_string($name)."\n";

                                $email_message .= "Email: ".clean_string($email_from)."\n";

                                $email_message .= "Telephone: ".clean_string($telephone)."\n";

                                $email_message .= "Message: ".clean_string($message)."\n";



                            // create email headers
                            //email to admin
                                    
                            $headers = 'From: '.$email_from."\r\n".

                            'Reply-To: '.$email_from."\r\n" .

                            'X-Mailer: PHP/' . phpversion();

                            @mail($email_to, $email_subject, $email_message, $headers);  
                            
                                    
                            //email confirmation to client
                                    
                                    
                            $confirm_email = 'noreply@spellmanconsulting.com';         

                            $confirm_subject = 'Spellman Consulting - Contact Confirmation';        
                            
                            $confirm_message =
                                    'Dear sir / madam,'
                                    ."\r\n"
                                    ."\r\n"
                                    .'Thank you for contacting Spellman Consulting.  Your message has been received and you can expect a reply soon.'
                                    ."\r\n"
                                    ."\r\n"
                                    .'Sincerely,'
                                    ."\r\n"
                                    ."\r\n"
                                    .'Spellman Consulting Team';          

                            $confirm_headers = 'From: '.$confirm_email."\r\n".

                            'Reply-To: '.$confirm_email."\r\n" .

                            'X-Mailer: PHP/' . phpversion();

                            @mail($email_from,$confirm_subject,$confirm_message, $confirm_headers);  
                            

                            }
}
else
{
//redirect code will need to be here
header("Location: http://www.jjwalker.net/lts/final/error.html");
}

}
else
{
    
    //redirect code will need to be here
header("Location: http://www.jjwalker.net/lts/final/error.html");
}

}

    
?>